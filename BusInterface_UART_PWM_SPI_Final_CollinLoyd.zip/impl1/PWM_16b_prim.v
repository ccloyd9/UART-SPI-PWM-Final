// Verilog netlist produced by program LSE :  version Diamond (64-bit) 3.13.0.56.2
// Netlist written on Sun Apr 19 15:34:11 2026
//
// Verilog Description of module PWM_16b
//

module PWM_16b (clk, rst, DC, Phase, En, PWM_Out);   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(297[8:15])
    input clk;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(301[12:15])
    input rst;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(302[12:15])
    input [15:0]DC;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    input [15:0]Phase;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    input En;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(305[12:14])
    output PWM_Out;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(306[12:19])
    
    wire clk_c /* synthesis is_clock=1, SET_AS_NETWORK=clk_c */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(301[12:15])
    
    wire GND_net, VCC_net, rst_c, DC_c_15, DC_c_14, DC_c_13, DC_c_12, 
        DC_c_11, DC_c_10, DC_c_9, DC_c_8, DC_c_7, DC_c_6, DC_c_5, 
        DC_c_4, Phase_c_15, Phase_c_14, Phase_c_13, Phase_c_12, Phase_c_11, 
        Phase_c_10, Phase_c_9, Phase_c_8, Phase_c_7, Phase_c_6, Phase_c_5, 
        Phase_c_4, En_c, PWM_Out_c;
    wire [15:0]PWM_Count;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(318[9:18])
    
    wire n469, n468, n467, n466;
    wire [15:0]DC_Read;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(318[20:27])
    
    wire n465, n464, n463, n462;
    wire [15:0]Phase_Read;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(318[29:39])
    
    wire n461, n675, n674, n685, n379, n386, n504, n93, n94, 
        n95, n96, n97, n98, n99, n100, n101, n102, n103, n104, 
        n105, n106, n107, n108;
    wire [15:0]PWM_Count_15__N_51;
    
    wire n684, n683, n488, n677, PWM_Out_N_69, n328, n460, n389, 
        n388, n387, n385, n384, n383, n382, n381, n380, n378, 
        n505, n357, n703, n682, n681, n673, n680, n689, n679, 
        n672, n678, n688, n648, n671, n687, n670, n669, n686, 
        n668, n667, n666, n665, n664, n663, n472, n470, n662, 
        n661, n660, n659, n658, n657, n656, n655, n654, n653, 
        n652, n651, n650, n649;
    
    VHI i2 (.Z(VCC_net));
    IB rst_pad (.I(rst), .O(rst_c));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(302[12:15])
    LUT4 i84_1_lut (.A(rst_c), .Z(n504)) /* synthesis lut_function=(!(A)) */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(302[12:15])
    defparam i84_1_lut.init = 16'h5555;
    FD1S3IX Phase_Read__i1 (.D(Phase_c_4), .CK(clk_c), .CD(n504), .Q(Phase_Read[0])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i1.GSR = "ENABLED";
    LUT4 mux_12_i11_3_lut_4_lut (.A(n328), .B(n703), .C(n98), .D(Phase_Read[10]), 
         .Z(PWM_Count_15__N_51[10])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i11_3_lut_4_lut.init = 16'hfd20;
    FD1S3IX DC_Read__i1 (.D(DC_c_4), .CK(clk_c), .CD(n504), .Q(DC_Read[0])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i1.GSR = "ENABLED";
    IB clk_pad (.I(clk), .O(clk_c));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(301[12:15])
    IB DC_pad_15 (.I(DC[15]), .O(DC_c_15));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    LUT4 mux_12_i12_3_lut_4_lut (.A(n328), .B(n703), .C(n97), .D(Phase_Read[11]), 
         .Z(PWM_Count_15__N_51[11])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i12_3_lut_4_lut.init = 16'hfd20;
    LUT4 i2_3_lut_rep_2 (.A(PWM_Count[13]), .B(PWM_Count[14]), .C(PWM_Count[15]), 
         .Z(n703)) /* synthesis lut_function=(A+(B+(C))) */ ;
    defparam i2_3_lut_rep_2.init = 16'hfefe;
    LUT4 mux_12_i2_3_lut_4_lut (.A(n328), .B(n703), .C(n107), .D(Phase_Read[1]), 
         .Z(PWM_Count_15__N_51[1])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i2_3_lut_4_lut.init = 16'hfd20;
    CCU2D add_11_3 (.A0(PWM_Count[1]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[2]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n649), .COUT(n650), .S0(n107), .S1(n106));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_3.INIT0 = 16'h5aaa;
    defparam add_11_3.INIT1 = 16'h5aaa;
    defparam add_11_3.INJECT1_0 = "NO";
    defparam add_11_3.INJECT1_1 = "NO";
    LUT4 mux_12_i1_3_lut_4_lut (.A(n328), .B(n703), .C(n108), .D(Phase_Read[0]), 
         .Z(PWM_Count_15__N_51[0])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i1_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_12_i7_3_lut_4_lut (.A(n328), .B(n703), .C(n102), .D(Phase_Read[6]), 
         .Z(PWM_Count_15__N_51[6])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i7_3_lut_4_lut.init = 16'hfd20;
    LUT4 i228_2_lut (.A(En_c), .B(rst_c), .Z(n488)) /* synthesis lut_function=(!(A (B))) */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(370[2] 386[15])
    defparam i228_2_lut.init = 16'h7777;
    OB PWM_Out_pad (.I(PWM_Out_c), .O(PWM_Out));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(306[12:19])
    LUT4 i1_4_lut (.A(n703), .B(n648), .C(n357), .D(PWM_Count[12]), 
         .Z(PWM_Out_N_69)) /* synthesis lut_function=(!(A+!(B ((D)+!C)))) */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(379[11:81])
    defparam i1_4_lut.init = 16'h4404;
    LUT4 mux_12_i5_3_lut_4_lut (.A(n328), .B(n703), .C(n104), .D(Phase_Read[4]), 
         .Z(PWM_Count_15__N_51[4])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i5_3_lut_4_lut.init = 16'hfd20;
    CCU2D add_11_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[0]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .COUT(n649), .S1(n108));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_1.INIT0 = 16'hF000;
    defparam add_11_1.INIT1 = 16'h5555;
    defparam add_11_1.INJECT1_0 = "NO";
    defparam add_11_1.INJECT1_1 = "NO";
    FD1S3IX DC_Read__i2 (.D(DC_c_5), .CK(clk_c), .CD(n504), .Q(DC_Read[1])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i2.GSR = "ENABLED";
    LUT4 mux_12_i8_3_lut_4_lut (.A(n328), .B(n703), .C(n101), .D(Phase_Read[7]), 
         .Z(PWM_Count_15__N_51[7])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i8_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_12_i6_3_lut_4_lut (.A(n328), .B(n703), .C(n103), .D(Phase_Read[5]), 
         .Z(PWM_Count_15__N_51[5])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i6_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_12_i9_3_lut_4_lut (.A(n328), .B(n703), .C(n100), .D(Phase_Read[8]), 
         .Z(PWM_Count_15__N_51[8])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i9_3_lut_4_lut.init = 16'hfd20;
    FD1S3IX PWM_Count__i12 (.D(n96), .CK(clk_c), .CD(n505), .Q(PWM_Count[12])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i12.GSR = "ENABLED";
    FD1S3IX PWM_Count__i0 (.D(PWM_Count_15__N_51[0]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[0])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i0.GSR = "ENABLED";
    FD1S3IX PWM_Out_28 (.D(PWM_Out_N_69), .CK(clk_c), .CD(n488), .Q(PWM_Out_c));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(370[2] 386[15])
    defparam PWM_Out_28.GSR = "ENABLED";
    IB DC_pad_14 (.I(DC[14]), .O(DC_c_14));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_13 (.I(DC[13]), .O(DC_c_13));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_12 (.I(DC[12]), .O(DC_c_12));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_11 (.I(DC[11]), .O(DC_c_11));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_10 (.I(DC[10]), .O(DC_c_10));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_9 (.I(DC[9]), .O(DC_c_9));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_8 (.I(DC[8]), .O(DC_c_8));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_7 (.I(DC[7]), .O(DC_c_7));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_6 (.I(DC[6]), .O(DC_c_6));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_5 (.I(DC[5]), .O(DC_c_5));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB DC_pad_4 (.I(DC[4]), .O(DC_c_4));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(303[12:14])
    IB Phase_pad_15 (.I(Phase[15]), .O(Phase_c_15));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_14 (.I(Phase[14]), .O(Phase_c_14));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_13 (.I(Phase[13]), .O(Phase_c_13));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_12 (.I(Phase[12]), .O(Phase_c_12));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_11 (.I(Phase[11]), .O(Phase_c_11));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_10 (.I(Phase[10]), .O(Phase_c_10));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_9 (.I(Phase[9]), .O(Phase_c_9));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_8 (.I(Phase[8]), .O(Phase_c_8));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_7 (.I(Phase[7]), .O(Phase_c_7));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_6 (.I(Phase[6]), .O(Phase_c_6));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_5 (.I(Phase[5]), .O(Phase_c_5));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB Phase_pad_4 (.I(Phase[4]), .O(Phase_c_4));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(304[12:17])
    IB En_pad (.I(En), .O(En_c));   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(305[12:14])
    CCU2D add_11_5 (.A0(PWM_Count[3]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[4]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n650), .COUT(n651), .S0(n105), .S1(n104));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_5.INIT0 = 16'h5aaa;
    defparam add_11_5.INIT1 = 16'h5aaa;
    defparam add_11_5.INJECT1_0 = "NO";
    defparam add_11_5.INJECT1_1 = "NO";
    FD1S3IX DC_Read__i3 (.D(DC_c_6), .CK(clk_c), .CD(n504), .Q(DC_Read[2])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i3.GSR = "ENABLED";
    FD1S3IX DC_Read__i4 (.D(DC_c_7), .CK(clk_c), .CD(n504), .Q(DC_Read[3])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i4.GSR = "ENABLED";
    FD1S3IX DC_Read__i5 (.D(DC_c_8), .CK(clk_c), .CD(n504), .Q(DC_Read[4])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i5.GSR = "ENABLED";
    FD1S3IX DC_Read__i6 (.D(DC_c_9), .CK(clk_c), .CD(n504), .Q(DC_Read[5])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i6.GSR = "ENABLED";
    FD1S3IX DC_Read__i7 (.D(DC_c_10), .CK(clk_c), .CD(n504), .Q(DC_Read[6])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i7.GSR = "ENABLED";
    FD1S3IX DC_Read__i8 (.D(DC_c_11), .CK(clk_c), .CD(n504), .Q(DC_Read[7])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i8.GSR = "ENABLED";
    FD1S3IX DC_Read__i9 (.D(DC_c_12), .CK(clk_c), .CD(n504), .Q(DC_Read[8])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i9.GSR = "ENABLED";
    FD1S3IX DC_Read__i10 (.D(DC_c_13), .CK(clk_c), .CD(n504), .Q(DC_Read[9])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i10.GSR = "ENABLED";
    FD1S3IX DC_Read__i11 (.D(DC_c_14), .CK(clk_c), .CD(n504), .Q(DC_Read[10])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i11.GSR = "ENABLED";
    FD1S3IX DC_Read__i12 (.D(DC_c_15), .CK(clk_c), .CD(n504), .Q(DC_Read[11])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam DC_Read__i12.GSR = "ENABLED";
    FD1S3IX PWM_Count__i1 (.D(PWM_Count_15__N_51[1]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[1])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i1.GSR = "ENABLED";
    FD1S3IX PWM_Count__i2 (.D(PWM_Count_15__N_51[2]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[2])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i2.GSR = "ENABLED";
    FD1S3IX PWM_Count__i3 (.D(PWM_Count_15__N_51[3]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[3])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i3.GSR = "ENABLED";
    FD1S3IX PWM_Count__i4 (.D(PWM_Count_15__N_51[4]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[4])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i4.GSR = "ENABLED";
    FD1S3IX PWM_Count__i5 (.D(PWM_Count_15__N_51[5]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[5])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i5.GSR = "ENABLED";
    FD1S3IX PWM_Count__i6 (.D(PWM_Count_15__N_51[6]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[6])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i6.GSR = "ENABLED";
    FD1S3IX PWM_Count__i7 (.D(PWM_Count_15__N_51[7]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[7])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i7.GSR = "ENABLED";
    FD1S3IX PWM_Count__i8 (.D(PWM_Count_15__N_51[8]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[8])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i8.GSR = "ENABLED";
    FD1S3IX PWM_Count__i9 (.D(PWM_Count_15__N_51[9]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[9])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i9.GSR = "ENABLED";
    FD1S3IX PWM_Count__i10 (.D(PWM_Count_15__N_51[10]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[10])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i10.GSR = "ENABLED";
    FD1S3IX PWM_Count__i11 (.D(PWM_Count_15__N_51[11]), .CK(clk_c), .CD(n504), 
            .Q(PWM_Count[11])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i11.GSR = "ENABLED";
    FD1S3IX PWM_Count__i13 (.D(n95), .CK(clk_c), .CD(n505), .Q(PWM_Count[13])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i13.GSR = "ENABLED";
    FD1S3IX PWM_Count__i14 (.D(n94), .CK(clk_c), .CD(n505), .Q(PWM_Count[14])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i14.GSR = "ENABLED";
    FD1S3IX PWM_Count__i15 (.D(n93), .CK(clk_c), .CD(n505), .Q(PWM_Count[15])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(354[2] 367[14])
    defparam PWM_Count__i15.GSR = "ENABLED";
    FD1S3IX Phase_Read__i2 (.D(Phase_c_5), .CK(clk_c), .CD(n504), .Q(Phase_Read[1])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i2.GSR = "ENABLED";
    LUT4 mux_12_i4_3_lut_4_lut (.A(n328), .B(n703), .C(n105), .D(Phase_Read[3]), 
         .Z(PWM_Count_15__N_51[3])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i4_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_12_i10_3_lut_4_lut (.A(n328), .B(n703), .C(n99), .D(Phase_Read[9]), 
         .Z(PWM_Count_15__N_51[9])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i10_3_lut_4_lut.init = 16'hfd20;
    LUT4 mux_12_i3_3_lut_4_lut (.A(n328), .B(n703), .C(n106), .D(Phase_Read[2]), 
         .Z(PWM_Count_15__N_51[2])) /* synthesis lut_function=(A (B (D)+!B (C))+!A (D)) */ ;
    defparam mux_12_i3_3_lut_4_lut.init = 16'hfd20;
    LUT4 i225_2_lut_3_lut (.A(n328), .B(n703), .C(rst_c), .Z(n505)) /* synthesis lut_function=((B+!(C))+!A) */ ;
    defparam i225_2_lut_3_lut.init = 16'hdfdf;
    VLO i1 (.Z(GND_net));
    FD1S3IX Phase_Read__i3 (.D(Phase_c_6), .CK(clk_c), .CD(n504), .Q(Phase_Read[2])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i3.GSR = "ENABLED";
    FD1S3IX Phase_Read__i4 (.D(Phase_c_7), .CK(clk_c), .CD(n504), .Q(Phase_Read[3])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i4.GSR = "ENABLED";
    FD1S3IX Phase_Read__i5 (.D(Phase_c_8), .CK(clk_c), .CD(n504), .Q(Phase_Read[4])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i5.GSR = "ENABLED";
    FD1S3IX Phase_Read__i6 (.D(Phase_c_9), .CK(clk_c), .CD(n504), .Q(Phase_Read[5])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i6.GSR = "ENABLED";
    FD1S3IX Phase_Read__i7 (.D(Phase_c_10), .CK(clk_c), .CD(n504), .Q(Phase_Read[6])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i7.GSR = "ENABLED";
    FD1S3IX Phase_Read__i8 (.D(Phase_c_11), .CK(clk_c), .CD(n504), .Q(Phase_Read[7])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i8.GSR = "ENABLED";
    FD1S3IX Phase_Read__i9 (.D(Phase_c_12), .CK(clk_c), .CD(n504), .Q(Phase_Read[8])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i9.GSR = "ENABLED";
    FD1S3IX Phase_Read__i10 (.D(Phase_c_13), .CK(clk_c), .CD(n504), .Q(Phase_Read[9])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i10.GSR = "ENABLED";
    FD1S3IX Phase_Read__i11 (.D(Phase_c_14), .CK(clk_c), .CD(n504), .Q(Phase_Read[10])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i11.GSR = "ENABLED";
    FD1S3IX Phase_Read__i12 (.D(Phase_c_15), .CK(clk_c), .CD(n504), .Q(Phase_Read[11])) /* synthesis lse_init_val=0 */ ;   // c:/fpga class/businterface_uart_pwm_spi/generic_components.vhd(323[2] 352[14])
    defparam Phase_Read__i12.GSR = "ENABLED";
    PUR PUR_INST (.PUR(VCC_net));
    defparam PUR_INST.RST_PULSE = 1;
    GSR GSR_INST (.GSR(VCC_net));
    CCU2D add_214_cout (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n689), 
          .S0(n648));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_cout.INIT0 = 16'h0000;
    defparam add_214_cout.INIT1 = 16'h0000;
    defparam add_214_cout.INJECT1_0 = "NO";
    defparam add_214_cout.INJECT1_1 = "NO";
    CCU2D add_214_13 (.A0(n460), .B0(PWM_Count[11]), .C0(GND_net), .D0(GND_net), 
          .A1(n472), .B1(PWM_Count[12]), .C1(GND_net), .D1(GND_net), 
          .CIN(n688), .COUT(n689));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_13.INIT0 = 16'h5999;
    defparam add_214_13.INIT1 = 16'h5999;
    defparam add_214_13.INJECT1_0 = "NO";
    defparam add_214_13.INJECT1_1 = "NO";
    CCU2D add_214_11 (.A0(n462), .B0(PWM_Count[9]), .C0(GND_net), .D0(GND_net), 
          .A1(n461), .B1(PWM_Count[10]), .C1(GND_net), .D1(GND_net), 
          .CIN(n687), .COUT(n688));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_11.INIT0 = 16'h5999;
    defparam add_214_11.INIT1 = 16'h5999;
    defparam add_214_11.INJECT1_0 = "NO";
    defparam add_214_11.INJECT1_1 = "NO";
    CCU2D add_214_9 (.A0(n464), .B0(PWM_Count[7]), .C0(GND_net), .D0(GND_net), 
          .A1(n463), .B1(PWM_Count[8]), .C1(GND_net), .D1(GND_net), 
          .CIN(n686), .COUT(n687));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_9.INIT0 = 16'h5999;
    defparam add_214_9.INIT1 = 16'h5999;
    defparam add_214_9.INJECT1_0 = "NO";
    defparam add_214_9.INJECT1_1 = "NO";
    CCU2D add_214_7 (.A0(n466), .B0(PWM_Count[5]), .C0(GND_net), .D0(GND_net), 
          .A1(n465), .B1(PWM_Count[6]), .C1(GND_net), .D1(GND_net), 
          .CIN(n685), .COUT(n686));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_7.INIT0 = 16'h5999;
    defparam add_214_7.INIT1 = 16'h5999;
    defparam add_214_7.INJECT1_0 = "NO";
    defparam add_214_7.INJECT1_1 = "NO";
    CCU2D add_214_5 (.A0(n468), .B0(PWM_Count[3]), .C0(GND_net), .D0(GND_net), 
          .A1(n467), .B1(PWM_Count[4]), .C1(GND_net), .D1(GND_net), 
          .CIN(n684), .COUT(n685));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_5.INIT0 = 16'h5999;
    defparam add_214_5.INIT1 = 16'h5999;
    defparam add_214_5.INJECT1_0 = "NO";
    defparam add_214_5.INJECT1_1 = "NO";
    CCU2D add_214_3 (.A0(n470), .B0(PWM_Count[1]), .C0(GND_net), .D0(GND_net), 
          .A1(n469), .B1(PWM_Count[2]), .C1(GND_net), .D1(GND_net), 
          .CIN(n683), .COUT(n684));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_3.INIT0 = 16'h5999;
    defparam add_214_3.INIT1 = 16'h5999;
    defparam add_214_3.INJECT1_0 = "NO";
    defparam add_214_3.INJECT1_1 = "NO";
    CCU2D add_214_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(DC_Read[0]), .B1(Phase_Read[0]), .C1(PWM_Count[0]), .D1(GND_net), 
          .COUT(n683));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_214_1.INIT0 = 16'h0000;
    defparam add_214_1.INIT1 = 16'h9969;
    defparam add_214_1.INJECT1_0 = "NO";
    defparam add_214_1.INJECT1_1 = "NO";
    CCU2D add_65_cout (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n682), 
          .S0(n472));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_cout.INIT0 = 16'h0000;
    defparam add_65_cout.INIT1 = 16'h0000;
    defparam add_65_cout.INJECT1_0 = "NO";
    defparam add_65_cout.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_11 (.A0(Phase_Read[9]), .B0(PWM_Count[9]), .C0(GND_net), 
          .D0(GND_net), .A1(Phase_Read[10]), .B1(PWM_Count[10]), .C1(GND_net), 
          .D1(GND_net), .CIN(n674), .COUT(n675));
    defparam sub_51_add_2_11.INIT0 = 16'h5999;
    defparam sub_51_add_2_11.INIT1 = 16'h5999;
    defparam sub_51_add_2_11.INJECT1_0 = "NO";
    defparam sub_51_add_2_11.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_13 (.A0(n378), .B0(PWM_Count[11]), .C0(GND_net), 
          .D0(GND_net), .A1(n389), .B1(PWM_Count[12]), .C1(GND_net), 
          .D1(GND_net), .CIN(n668), .COUT(n669));
    defparam sub_49_add_2_13.INIT0 = 16'h5999;
    defparam sub_49_add_2_13.INIT1 = 16'h5999;
    defparam sub_49_add_2_13.INJECT1_0 = "NO";
    defparam sub_49_add_2_13.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_11 (.A0(n380), .B0(PWM_Count[9]), .C0(GND_net), 
          .D0(GND_net), .A1(n379), .B1(PWM_Count[10]), .C1(GND_net), 
          .D1(GND_net), .CIN(n667), .COUT(n668));
    defparam sub_49_add_2_11.INIT0 = 16'h5999;
    defparam sub_49_add_2_11.INIT1 = 16'h5999;
    defparam sub_49_add_2_11.INJECT1_0 = "NO";
    defparam sub_49_add_2_11.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_9 (.A0(n382), .B0(PWM_Count[7]), .C0(GND_net), 
          .D0(GND_net), .A1(n381), .B1(PWM_Count[8]), .C1(GND_net), 
          .D1(GND_net), .CIN(n666), .COUT(n667));
    defparam sub_49_add_2_9.INIT0 = 16'h5999;
    defparam sub_49_add_2_9.INIT1 = 16'h5999;
    defparam sub_49_add_2_9.INJECT1_0 = "NO";
    defparam sub_49_add_2_9.INJECT1_1 = "NO";
    TSALL TSALL_INST (.TSALL(GND_net));
    CCU2D sub_49_add_2_7 (.A0(n384), .B0(PWM_Count[5]), .C0(GND_net), 
          .D0(GND_net), .A1(n383), .B1(PWM_Count[6]), .C1(GND_net), 
          .D1(GND_net), .CIN(n665), .COUT(n666));
    defparam sub_49_add_2_7.INIT0 = 16'h5999;
    defparam sub_49_add_2_7.INIT1 = 16'h5999;
    defparam sub_49_add_2_7.INJECT1_0 = "NO";
    defparam sub_49_add_2_7.INJECT1_1 = "NO";
    CCU2D add_11_13 (.A0(PWM_Count[11]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[12]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n654), .COUT(n655), .S0(n97), .S1(n96));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_13.INIT0 = 16'h5aaa;
    defparam add_11_13.INIT1 = 16'h5aaa;
    defparam add_11_13.INJECT1_0 = "NO";
    defparam add_11_13.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_5 (.A0(n386), .B0(PWM_Count[3]), .C0(GND_net), 
          .D0(GND_net), .A1(n385), .B1(PWM_Count[4]), .C1(GND_net), 
          .D1(GND_net), .CIN(n664), .COUT(n665));
    defparam sub_49_add_2_5.INIT0 = 16'h5999;
    defparam sub_49_add_2_5.INIT1 = 16'h5999;
    defparam sub_49_add_2_5.INJECT1_0 = "NO";
    defparam sub_49_add_2_5.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_3 (.A0(n388), .B0(PWM_Count[1]), .C0(GND_net), 
          .D0(GND_net), .A1(n387), .B1(PWM_Count[2]), .C1(GND_net), 
          .D1(GND_net), .CIN(n663), .COUT(n664));
    defparam sub_49_add_2_3.INIT0 = 16'h5999;
    defparam sub_49_add_2_3.INIT1 = 16'h5999;
    defparam sub_49_add_2_3.INJECT1_0 = "NO";
    defparam sub_49_add_2_3.INJECT1_1 = "NO";
    CCU2D add_11_11 (.A0(PWM_Count[9]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[10]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n653), .COUT(n654), .S0(n99), .S1(n98));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_11.INIT0 = 16'h5aaa;
    defparam add_11_11.INIT1 = 16'h5aaa;
    defparam add_11_11.INJECT1_0 = "NO";
    defparam add_11_11.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_9 (.A0(Phase_Read[7]), .B0(PWM_Count[7]), .C0(GND_net), 
          .D0(GND_net), .A1(Phase_Read[8]), .B1(PWM_Count[8]), .C1(GND_net), 
          .D1(GND_net), .CIN(n673), .COUT(n674));
    defparam sub_51_add_2_9.INIT0 = 16'h5999;
    defparam sub_51_add_2_9.INIT1 = 16'h5999;
    defparam sub_51_add_2_9.INJECT1_0 = "NO";
    defparam sub_51_add_2_9.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[0]), .B1(PWM_Count[0]), .C1(GND_net), .D1(GND_net), 
          .COUT(n663));
    defparam sub_49_add_2_1.INIT0 = 16'h0000;
    defparam sub_49_add_2_1.INIT1 = 16'h5999;
    defparam sub_49_add_2_1.INJECT1_0 = "NO";
    defparam sub_49_add_2_1.INJECT1_1 = "NO";
    CCU2D add_57_cout (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n662), 
          .S0(n389));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_cout.INIT0 = 16'h0000;
    defparam add_57_cout.INIT1 = 16'h0000;
    defparam add_57_cout.INJECT1_0 = "NO";
    defparam add_57_cout.INJECT1_1 = "NO";
    CCU2D add_57_11 (.A0(Phase_Read[10]), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(Phase_Read[11]), .B1(GND_net), .C1(GND_net), 
          .D1(GND_net), .CIN(n661), .COUT(n662), .S0(n379), .S1(n378));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_11.INIT0 = 16'h0555;
    defparam add_57_11.INIT1 = 16'h0555;
    defparam add_57_11.INJECT1_0 = "NO";
    defparam add_57_11.INJECT1_1 = "NO";
    CCU2D add_57_9 (.A0(Phase_Read[8]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[9]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n660), .COUT(n661), .S0(n381), .S1(n380));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_9.INIT0 = 16'h0555;
    defparam add_57_9.INIT1 = 16'h0555;
    defparam add_57_9.INJECT1_0 = "NO";
    defparam add_57_9.INJECT1_1 = "NO";
    CCU2D add_57_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[1]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .COUT(n657), .S1(n388));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_1.INIT0 = 16'hF000;
    defparam add_57_1.INIT1 = 16'h0555;
    defparam add_57_1.INJECT1_0 = "NO";
    defparam add_57_1.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_7 (.A0(Phase_Read[5]), .B0(PWM_Count[5]), .C0(GND_net), 
          .D0(GND_net), .A1(Phase_Read[6]), .B1(PWM_Count[6]), .C1(GND_net), 
          .D1(GND_net), .CIN(n672), .COUT(n673));
    defparam sub_51_add_2_7.INIT0 = 16'h5999;
    defparam sub_51_add_2_7.INIT1 = 16'h5999;
    defparam sub_51_add_2_7.INJECT1_0 = "NO";
    defparam sub_51_add_2_7.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_5 (.A0(Phase_Read[3]), .B0(PWM_Count[3]), .C0(GND_net), 
          .D0(GND_net), .A1(Phase_Read[4]), .B1(PWM_Count[4]), .C1(GND_net), 
          .D1(GND_net), .CIN(n671), .COUT(n672));
    defparam sub_51_add_2_5.INIT0 = 16'h5999;
    defparam sub_51_add_2_5.INIT1 = 16'h5999;
    defparam sub_51_add_2_5.INJECT1_0 = "NO";
    defparam sub_51_add_2_5.INJECT1_1 = "NO";
    CCU2D add_11_9 (.A0(PWM_Count[7]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[8]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n652), .COUT(n653), .S0(n101), .S1(n100));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_9.INIT0 = 16'h5aaa;
    defparam add_11_9.INIT1 = 16'h5aaa;
    defparam add_11_9.INJECT1_0 = "NO";
    defparam add_11_9.INJECT1_1 = "NO";
    CCU2D add_11_7 (.A0(PWM_Count[5]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[6]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n651), .COUT(n652), .S0(n103), .S1(n102));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_7.INIT0 = 16'h5aaa;
    defparam add_11_7.INIT1 = 16'h5aaa;
    defparam add_11_7.INJECT1_0 = "NO";
    defparam add_11_7.INJECT1_1 = "NO";
    CCU2D add_11_17 (.A0(PWM_Count[15]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), .CIN(n656), 
          .S0(n93));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_17.INIT0 = 16'h5aaa;
    defparam add_11_17.INIT1 = 16'h0000;
    defparam add_11_17.INJECT1_0 = "NO";
    defparam add_11_17.INJECT1_1 = "NO";
    CCU2D add_11_15 (.A0(PWM_Count[13]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(PWM_Count[14]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n655), .COUT(n656), .S0(n95), .S1(n94));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(118[20:31])
    defparam add_11_15.INIT0 = 16'h5aaa;
    defparam add_11_15.INIT1 = 16'h5aaa;
    defparam add_11_15.INJECT1_0 = "NO";
    defparam add_11_15.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_3 (.A0(Phase_Read[1]), .B0(PWM_Count[1]), .C0(GND_net), 
          .D0(GND_net), .A1(Phase_Read[2]), .B1(PWM_Count[2]), .C1(GND_net), 
          .D1(GND_net), .CIN(n670), .COUT(n671));
    defparam sub_51_add_2_3.INIT0 = 16'h5999;
    defparam sub_51_add_2_3.INIT1 = 16'h5999;
    defparam sub_51_add_2_3.INJECT1_0 = "NO";
    defparam sub_51_add_2_3.INJECT1_1 = "NO";
    CCU2D add_57_7 (.A0(Phase_Read[6]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[7]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n659), .COUT(n660), .S0(n383), .S1(n382));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_7.INIT0 = 16'h0555;
    defparam add_57_7.INIT1 = 16'h0555;
    defparam add_57_7.INJECT1_0 = "NO";
    defparam add_57_7.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_1 (.A0(GND_net), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[0]), .B1(PWM_Count[0]), .C1(GND_net), .D1(GND_net), 
          .COUT(n670));
    defparam sub_51_add_2_1.INIT0 = 16'h0000;
    defparam sub_51_add_2_1.INIT1 = 16'h5999;
    defparam sub_51_add_2_1.INJECT1_0 = "NO";
    defparam sub_51_add_2_1.INJECT1_1 = "NO";
    CCU2D add_57_5 (.A0(Phase_Read[4]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[5]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n658), .COUT(n659), .S0(n385), .S1(n384));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_5.INIT0 = 16'h0555;
    defparam add_57_5.INIT1 = 16'h0555;
    defparam add_57_5.INJECT1_0 = "NO";
    defparam add_57_5.INJECT1_1 = "NO";
    CCU2D sub_49_add_2_cout (.A0(GND_net), .B0(GND_net), .C0(GND_net), 
          .D0(GND_net), .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n669), .S0(n328));
    defparam sub_49_add_2_cout.INIT0 = 16'h0000;
    defparam sub_49_add_2_cout.INIT1 = 16'h0000;
    defparam sub_49_add_2_cout.INJECT1_0 = "NO";
    defparam sub_49_add_2_cout.INJECT1_1 = "NO";
    CCU2D add_57_3 (.A0(Phase_Read[2]), .B0(GND_net), .C0(GND_net), .D0(GND_net), 
          .A1(Phase_Read[3]), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n657), .COUT(n658), .S0(n387), .S1(n386));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_unsi.vhd(125[20:21])
    defparam add_57_3.INIT0 = 16'h0555;
    defparam add_57_3.INIT1 = 16'h0555;
    defparam add_57_3.INJECT1_0 = "NO";
    defparam add_57_3.INJECT1_1 = "NO";
    CCU2D add_65_12 (.A0(DC_Read[10]), .B0(Phase_Read[10]), .C0(GND_net), 
          .D0(GND_net), .A1(DC_Read[11]), .B1(Phase_Read[11]), .C1(GND_net), 
          .D1(GND_net), .CIN(n681), .COUT(n682), .S0(n461), .S1(n460));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_12.INIT0 = 16'h5666;
    defparam add_65_12.INIT1 = 16'h5666;
    defparam add_65_12.INJECT1_0 = "NO";
    defparam add_65_12.INJECT1_1 = "NO";
    CCU2D add_65_10 (.A0(DC_Read[8]), .B0(Phase_Read[8]), .C0(GND_net), 
          .D0(GND_net), .A1(DC_Read[9]), .B1(Phase_Read[9]), .C1(GND_net), 
          .D1(GND_net), .CIN(n680), .COUT(n681), .S0(n463), .S1(n462));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_10.INIT0 = 16'h5666;
    defparam add_65_10.INIT1 = 16'h5666;
    defparam add_65_10.INJECT1_0 = "NO";
    defparam add_65_10.INJECT1_1 = "NO";
    CCU2D add_65_8 (.A0(DC_Read[6]), .B0(Phase_Read[6]), .C0(GND_net), 
          .D0(GND_net), .A1(DC_Read[7]), .B1(Phase_Read[7]), .C1(GND_net), 
          .D1(GND_net), .CIN(n679), .COUT(n680), .S0(n465), .S1(n464));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_8.INIT0 = 16'h5666;
    defparam add_65_8.INIT1 = 16'h5666;
    defparam add_65_8.INJECT1_0 = "NO";
    defparam add_65_8.INJECT1_1 = "NO";
    CCU2D add_65_6 (.A0(DC_Read[4]), .B0(Phase_Read[4]), .C0(GND_net), 
          .D0(GND_net), .A1(DC_Read[5]), .B1(Phase_Read[5]), .C1(GND_net), 
          .D1(GND_net), .CIN(n678), .COUT(n679), .S0(n467), .S1(n466));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_6.INIT0 = 16'h5666;
    defparam add_65_6.INIT1 = 16'h5666;
    defparam add_65_6.INJECT1_0 = "NO";
    defparam add_65_6.INJECT1_1 = "NO";
    CCU2D add_65_4 (.A0(DC_Read[2]), .B0(Phase_Read[2]), .C0(GND_net), 
          .D0(GND_net), .A1(DC_Read[3]), .B1(Phase_Read[3]), .C1(GND_net), 
          .D1(GND_net), .CIN(n677), .COUT(n678), .S0(n469), .S1(n468));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_4.INIT0 = 16'h5666;
    defparam add_65_4.INIT1 = 16'h5666;
    defparam add_65_4.INJECT1_0 = "NO";
    defparam add_65_4.INJECT1_1 = "NO";
    CCU2D add_65_2 (.A0(DC_Read[0]), .B0(Phase_Read[0]), .C0(GND_net), 
          .D0(GND_net), .A1(DC_Read[1]), .B1(Phase_Read[1]), .C1(GND_net), 
          .D1(GND_net), .COUT(n677), .S1(n470));   // C:/lscc/diamond/3.13/ispfpga/vhdl_packages/syn_arit.vhd(838[41:65])
    defparam add_65_2.INIT0 = 16'h7000;
    defparam add_65_2.INIT1 = 16'h5666;
    defparam add_65_2.INJECT1_0 = "NO";
    defparam add_65_2.INJECT1_1 = "NO";
    CCU2D sub_51_add_2_13 (.A0(Phase_Read[11]), .B0(PWM_Count[11]), .C0(GND_net), 
          .D0(GND_net), .A1(GND_net), .B1(GND_net), .C1(GND_net), .D1(GND_net), 
          .CIN(n675), .S1(n357));
    defparam sub_51_add_2_13.INIT0 = 16'h5999;
    defparam sub_51_add_2_13.INIT1 = 16'h0000;
    defparam sub_51_add_2_13.INJECT1_0 = "NO";
    defparam sub_51_add_2_13.INJECT1_1 = "NO";
    
endmodule
//
// Verilog Description of module PUR
// module not written out since it is a black-box. 
//

//
// Verilog Description of module TSALL
// module not written out since it is a black-box. 
//

